from doctest import OutputChecker
from tkinter import *
import tkinter.font as tkFont
import torch
import numpy as np
import torch.nn as nn
from pytorch_pretrained_bert import BertForTokenClassification, BertAdam

window = Tk()
window.title("NER GUI")
window.geometry("620x800")

font_row0 = tkFont.Font(family="Arial", size=20, weight="bold")
lbl = Label(window, text="Name Entity Recognition GUI", font=font_row0)
lbl.grid(column=0, row=0, columnspan=2)

class BiLSTMPOSTagger(nn.Module):
    def __init__(self, 
                 input_dim, 
                 embedding_dim, 
                 hidden_dim, 
                 output_dim, 
                 n_layers, 
                 bidirectional, 
                 dropout):
        
        super().__init__()
        
        self.embedding = nn.Embedding(input_dim, embedding_dim, padding_idx = 0)
        
        self.lstm_layer = nn.LSTM(embedding_dim, 
                            hidden_dim, 
                            num_layers = n_layers, 
                            bidirectional = bidirectional,
                            dropout = dropout if n_layers > 1 else 0)
        
        self.fc = nn.Linear(hidden_dim * 2 if bidirectional else hidden_dim, output_dim)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, text):
        embedded = self.dropout(self.embedding(text))
      
        output, (_, _) = self.lstm_layer(embedded)
        
        predictions = self.fc(output)
        
        return predictions # [sent len, batch size, output dim]

def clicked_lstm():
    #lbl.configure(text="Bi-directional LSTM-CRF model loaded!")
    input_data=txt.get("1.0",END)
    input_data=input_data.rstrip()
    input_data=input_data.replace('\n', '').replace('\r', '')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    model=torch.load("BiLSTM_model_weights.pth")

    endstr=input_data[-1]
    if endstr == "." or endstr == "!" or endstr == "?":
        input_split = input_data[:-1].strip().split(" ")
    else:
        input_split = input_data.split(" ")

    idx2tag = np.load('idx2tag.npy', allow_pickle='True').item()
    word2idx = np.load('word2idx.npy', allow_pickle='True').item()
    words = np.load('words.npy')

    X_te=[]
    for each in input_split:
        try:
            X_te.append(word2idx[each])
        except KeyError:
            X_te.append(0)
        

    lenth_add=75-len(X_te)
    for i in range(lenth_add):
        X_te.append(0)
    X_te=torch.from_numpy(np.array(X_te))
    
    #print(X_te.shape)

    predictions = model(X_te.to(device))
    predictions = predictions.view(-1, predictions.shape[-1])
    predictions=  list(np.argmax(predictions.detach().cpu().numpy(), axis=-1))

    output = "{:15}||  {}\n".format("Word", "Pred")
    # Visualization
    output+=30 * "="
    output+="\n"
    for w, pred in zip(X_te, predictions):
        if w != 0:
            output+="{:15}: {}\n".format(words[w-2], idx2tag[pred])
    
    lbl_output.configure(text=output)

def clicked_lstm_save():
    #lbl.configure(text="Bi-directional LSTM-CRF model loaded!")
    input_data=txt.get("1.0",END)
    input_data=input_data.rstrip()
    input_data=input_data.replace('\n', '').replace('\r', '')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    model=torch.load("BiLSTM_model_weights.pth")

    endstr=input_data[-1]
    if endstr == "." or endstr == "!" or endstr == "?":
        input_split = input_data[:-1].strip().split(" ")
    else:
        input_split = input_data.split(" ")

    idx2tag = np.load('idx2tag.npy', allow_pickle='True').item()
    word2idx = np.load('word2idx.npy', allow_pickle='True').item()
    words = np.load('words.npy')

    X_te=[]
    for each in input_split:
        try:
            X_te.append(word2idx[each])
        except KeyError:
            X_te.append(0)
        

    lenth_add=75-len(X_te)
    for i in range(lenth_add):
        X_te.append(0)
    X_te=torch.from_numpy(np.array(X_te))
    
    #print(X_te.shape)

    predictions = model(X_te.to(device))
    predictions = predictions.view(-1, predictions.shape[-1])
    predictions=  list(np.argmax(predictions.detach().cpu().numpy(), axis=-1))

    output = "{:15}||  {}\n".format("Word", "Pred")
    # Visualization
    output+=30 * "="
    output+="\n"
    for w, pred in zip(X_te, predictions):
        if w != 0:
            output+="{:15}: {}\n".format(words[w-2], idx2tag[pred])
    
    with open('output.txt','w') as f:
        f.write(output)
        f.close()



font_row1 =tkFont.Font(family="Arial", size=20)
lbl_in = Label(window, text="Input your sentence here:", font=font_row1)
lbl_in.grid(column=0, row=1, columnspan=2)

font_row3 = tkFont.Font(family="Arial", size=16)
btn_lstm = Button(window, text="Get Prediction with LSTM", command=clicked_lstm, font=font_row3)
btn_lstm.grid(column=0, row=3)

btn_lstm_save = Button(window, text="Get Prediction and Save", command=clicked_lstm_save, font=font_row3)
btn_lstm_save.grid(column=1, row=3)

txt = Text(window, width=50, font=font_row3, height=5)
txt.grid(column=0, row=2, columnspan=2)

font_res = tkFont.Font(family="Arial", size=16, weight="bold")
lbl_res = Label(window, text="Result", font=font_res)
lbl_res.grid(column=0, row=4, columnspan=2,rowspan=2)

font_out = tkFont.Font(family="Arial", size=10)
lbl_output = Label(window, text="", font=font_out)
#lbl_output.place(relx=0.5, rely=0.5, anchor=CENTER)
lbl_output.grid(column=0, row=6, columnspan=2)

window.mainloop()